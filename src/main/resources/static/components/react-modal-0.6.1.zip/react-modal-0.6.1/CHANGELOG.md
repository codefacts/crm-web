v0.6.1 - Fri, 23 Oct 2015 18:03:54 GMT
--------------------------------------

- 


v0.6.0 - Wed, 21 Oct 2015 21:39:48 GMT
--------------------------------------

- 


v0.5.0 - Tue, 22 Sep 2015 19:19:44 GMT
--------------------------------------

- [4d25989](../../commit/4d25989) [added] Inline CSS for modal and overlay as well as props to override. [changed] injectCSS has been changed to a warning message in preparation for a future removal. lib/components/Modal.js [changed] setAppElement method is now optional. Defaults to document.body and now allows for a css selector to be passed in rather than the whole element.
- [02cf2c3](../../commit/02cf2c3) [fixed] Clear the closeWithTimeout timer before unmounting


v0.3.0 - Wed, 15 Jul 2015 06:17:24 GMT
--------------------------------------

- [adecf62](../../commit/adecf62) [added] Class name on body when modal is open


v0.2.0 - Sat, 09 May 2015 05:16:40 GMT
--------------------------------------

- [f5fe537](../../commit/f5fe537) [added] Ability to specify style for the modal contents


v0.1.1 - Tue, 31 Mar 2015 15:56:47 GMT
--------------------------------------

- [f86de0a](../../commit/f86de0a) [fixed] shift+tab closes #23


v0.1.0 - Thu, 26 Feb 2015 17:14:27 GMT
--------------------------------------

- [1b8e2d0](../../commit/1b8e2d0) [fixed] ModalPortal's componentWillReceiveProps
- [28dbc63](../../commit/28dbc63) [added] Supporting custom overlay className closes #14
- [6626dae](../../commit/6626dae) [fixed] erroneous alias in webpack build


v0.0.7 - Sat, 03 Jan 2015 06:44:47 GMT
--------------------------------------

- 


v0.0.6 - Wed, 03 Dec 2014 21:24:45 GMT
--------------------------------------

- [28dbc63](../../commit/28dbc63) [added] Supporting custom overlay className closes #14
- [6626dae](../../commit/6626dae) [fixed] erroneous alias in webpack build


v0.0.5 - Thu, 13 Nov 2014 18:55:47 GMT
--------------------------------------

- [b15aa82](../../commit/b15aa82) [added] Supporting custom className
- [b7a38de](../../commit/b7a38de) [fixed] Warning caused by trying to focus null element closes #11


v0.0.4 - Tue, 11 Nov 2014 16:08:14 GMT
--------------------------------------

- [e57bab5](../../commit/e57bab5) [fixed] Issue with focus being lost - closes #9


v0.0.3 - Fri, 31 Oct 2014 19:25:20 GMT
--------------------------------------

- 


v0.0.2 - Thu, 25 Sep 2014 02:36:47 GMT
--------------------------------------

- 


v0.0.1 - Wed, 24 Sep 2014 22:26:40 GMT
--------------------------------------

- 


v0.0.0 - Wed, 24 Sep 2014 22:25:00 GMT
--------------------------------------

- 


